
import { GoogleGenAI, Type } from "@google/genai";
import { User, MatchScore } from "../types";

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  console.log("Checking API Key:", apiKey ? "Present (" + apiKey.slice(0, 5) + "...)" : "Missing");
  if (!apiKey) {
    console.error("Gemini API Key is missing in getAiClient");
    throw new Error("Gemini API Key is missing. Please check your .env.local file.");
  }
  return new GoogleGenAI({ apiKey });
};

export async function calculateMatchScores(currentUser: User, availableUsers: User[]): Promise<MatchScore[]> {
  const prompt = `
    You are an AI matchmaking engine for "SkillSwap", a peer-to-peer skill exchange platform.
    Your goal is to calculate a compatibility score (0-100) between the current user and other community members.
    
    A high score is awarded when User A's "skillsNeeded" overlap with User B's "skillsOffered" AND vice-versa.
    
    Current User:
    Name: ${currentUser.name}
    Offered: ${currentUser.skillsOffered.map(s => s.name).join(', ')}
    Needed: ${currentUser.skillsNeeded.map(s => s.name).join(', ')}
    
    Candidates:
    ${availableUsers.map(u => `
      - ID: ${u.id}
        Name: ${u.name}
        Offered: ${u.skillsOffered.map(s => s.name).join(', ')}
        Needed: ${u.skillsNeeded.map(s => s.name).join(', ')}
    `).join('\n')}
  `;

  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: "gemini-1.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              userId: { type: Type.STRING },
              score: { type: Type.NUMBER },
              reasoning: { type: Type.STRING },
              complementarySkills: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            },
            required: ["userId", "score", "reasoning", "complementarySkills"]
          }
        }
      }
    });

    const results = JSON.parse(response.text || "[]");
    return results;
  } catch (error) {
    console.error("Matchmaking failed:", error);
    return availableUsers.map(u => ({
      userId: u.id,
      score: Math.floor(Math.random() * 40) + 50,
      reasoning: "A potential match based on shared interests.",
      complementarySkills: [u.skillsOffered[0]?.name]
    }));
  }
}

// ... existing code ...

export async function generateSwapInsight(userA: User, userB: User): Promise<string> {
  const prompt = `
    Create a 3-step action plan for a 1-hour skill swap between ${userA.name} and ${userB.name}.
    ${userA.name} offers: ${userA.skillsOffered.map(s => s.name).join(', ')}
    ${userB.name} offers: ${userB.skillsOffered.map(s => s.name).join(', ')}
    Keep it concise and practical. Format it as a simple list.
  `;
  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: "gemini-1.5-flash",
      contents: prompt
    });
    return response.text || "No insights available at this time.";
  } catch (err) {
    return "Let's connect and figure out a plan together!";
  }
}

export async function generateChatResponse(
  history: any[], // using any to avoid type circular dependency issues if Message isn't exported safely, but ideally import Message
  currentUser: User,
  otherUser: User,
  incomingMessage: string
): Promise<string> {
  const conversationHistory = history.map(msg =>
    `${msg.senderId === 'me' ? currentUser.name : otherUser.name}: ${msg.text}`
  ).join('\n');

  const prompt = `
    You are roleplaying as ${otherUser.name} on a skill-sharing platform called SkillSwap.
    
    Your Profile:
    - Name: ${otherUser.name}
    - Skills You Offer: ${otherUser.skillsOffered.map(s => s.name).join(', ')}
    - Skills You Need: ${otherUser.skillsNeeded.map(s => s.name).join(', ')}
    - Bio: ${otherUser.bio || "Enthusiastic about sharing knowledge."}

    The User you are talking to:
    - Name: ${currentUser.name || "Use Partner"}
    
    Conversation Context:
    ${conversationHistory}
    ${currentUser.name}: ${incomingMessage}

    Rules:
    - Respond naturally as ${otherUser.name}.
    - Keep responses concise (under 3 sentences usually).
    - Be friendly and encouraging.
    - If the user proposes a swap, be enthusiastic (unless the skills don't match at all, then be polite but open).
    - Do not include timestamps or "System:" prefixes.
    
    Respond to: "${incomingMessage}"
  `;

  console.log("Generating chat with model: gemini-1.5-flash");
  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: "gemini-1.5-flash",
      contents: prompt
    });
    return response.text || "That sounds great!";
  } catch (error: any) {
    console.error("Chat generation failed DETAILED:", error);
    if (error.message) console.error("Error Message:", error.message);
    if (error.status) console.error("Error Status:", error.status);
    return `(Error: ${error?.message || "Unknown API Error"}. Please check console for details.)`;
  }
}
